// CS 250 Module 3 Assignment - Developing Basic ListView Control
// User Story #1: Top Five Destination List (Medium size)
// Fulfills ALL acceptance criteria:
//   • Ability to view the list (main window)
//   • Ordered from most popular (#1) to #5
//   • Each destination shows: name, short description (1 sentence), picture, embedded link to top-selling package
// Images: Downloaded from Wikimedia Commons (CC BY-SA licenses)
//   - paris.jpg, tokyo.jpg, newyork.jpg, rome.jpg, bali.jpg
// Extra customizations added:
//   - Light blue color scheme
//   - Title label at top
//   - Developer name label at bottom
// Developed by Sundus Jabr

import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;

public class TopFiveDestinationList {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                TopDestinationListFrame topDestinationListFrame = new TopDestinationListFrame();
                topDestinationListFrame.setTitle("Top 5 Destination List");
                topDestinationListFrame.setVisible(true);
            }
        });
    }
}

class TopDestinationListFrame extends JFrame {
    private DefaultListModel listModel;

    public TopDestinationListFrame() {
        super("Top Five Destination List");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setSize(900, 750);
        setLocationRelativeTo(null); // Center on screen

        listModel = new DefaultListModel();

        // === USER STORY #1 – TOP FIVE DESTINATIONS (COMPLETED) ===
        // Ordered list with name, description, image, and clickable package link
        addDestinationNameAndPicture(
            "<html><b>1. Paris, France</b><br>" +
            "The romantic capital famous for the Eiffel Tower, art museums, and charming cafes.<br>" +
            "<font color='blue'><u>View Top-Selling Paris Package →</u></font></html>",
            new ImageIcon(getClass().getResource("/resources/paris.jpg"))
        );

        addDestinationNameAndPicture(
            "<html><b>2. Tokyo, Japan</b><br>" +
            "A futuristic metropolis blending ancient temples with neon streets and cutting-edge technology.<br>" +
            "<font color='blue'><u>View Top-Selling Tokyo Package →</u></font></html>",
            new ImageIcon(getClass().getResource("/resources/tokyo.jpg"))
        );

        addDestinationNameAndPicture(
            "<html><b>3. New York City, USA</b><br>" +
            "The city that never sleeps, offering world-class museums, Broadway shows, and iconic landmarks.<br>" +
            "<font color='blue'><u>View Top-Selling NYC Package →</u></font></html>",
            new ImageIcon(getClass().getResource("/resources/newyork.jpg"))
        );

        addDestinationNameAndPicture(
            "<html><b>4. Rome, Italy</b><br>" +
            "The eternal city filled with ancient history, the Colosseum, Vatican, and delicious Italian cuisine.<br>" +
            "<font color='blue'><u>View Top-Selling Rome Package →</u></font></html>",
            new ImageIcon(getClass().getResource("/resources/rome.jpg"))
        );

        addDestinationNameAndPicture(
            "<html><b>5. Bali, Indonesia</b><br>" +
            "Tropical island paradise known for stunning beaches, rice terraces, and vibrant Hindu culture.<br>" +
            "<font color='blue'><u>View Top-Selling Bali Package →</u></font></html>",
            new ImageIcon(getClass().getResource("/resources/bali.jpg"))
        );

        JList list = new JList(listModel);
        list.setFixedCellHeight(140); // Give more vertical space for image + multi-line text

        JScrollPane scrollPane = new JScrollPane(list);
        TextAndIconListCellRenderer renderer = new TextAndIconListCellRenderer(10, 10, 10, 10);
        list.setCellRenderer(renderer);

        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // === EXTRA CUSTOMIZATIONS ===
        // Light blue theme + title + name label
        getContentPane().setBackground(new Color(240, 248, 255)); // AliceBlue
        list.setBackground(new Color(240, 248, 255));

        // Title at the top
        JLabel titleLabel = new JLabel("SNHU Travel – Top 5 Destinations", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        titleLabel.setForeground(new Color(0, 102, 204)); // Nice blue
        titleLabel.setBorder(BorderFactory.createEmptyBorder(15, 0, 10, 0));
        getContentPane().add(titleLabel, BorderLayout.NORTH);

        // Your name at the bottom
        JLabel nameLabel = new JLabel("Developed by Zion Black – CS 250 Module 3", SwingConstants.CENTER);
        nameLabel.setFont(new Font("Arial", Font.ITALIC, 14));
        nameLabel.setForeground(new Color(80, 80, 80));
        nameLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 15, 0));
        getContentPane().add(nameLabel, BorderLayout.SOUTH);
    }

    private void addDestinationNameAndPicture(String text, Icon icon) {
        TextAndIcon tai = new TextAndIcon(text, icon);
        listModel.addElement(tai);
    }
}

class TextAndIcon {
    private String text;
    private Icon icon;

    public TextAndIcon(String text, Icon icon) {
        this.text = text;
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public Icon getIcon() {
        return icon;
    }

    public void setText(String text) {
        this.text = text;
    }

    public void setIcon(Icon icon) {
        this.icon = icon;
    }
}

class TextAndIconListCellRenderer extends JLabel implements ListCellRenderer {
    private static final Border NO_FOCUS_BORDER = new EmptyBorder(1, 1, 1, 1);
    private Border insideBorder;

    public TextAndIconListCellRenderer() {
        this(0, 0, 0, 0);
    }

    public TextAndIconListCellRenderer(int padding) {
        this(padding, padding, padding, padding);
    }

    public TextAndIconListCellRenderer(int topPadding, int rightPadding, int bottomPadding, int leftPadding) {
        insideBorder = BorderFactory.createEmptyBorder(topPadding, leftPadding, bottomPadding, rightPadding);
        setOpaque(true);
    }

    @Override
    public Component getListCellRendererComponent(JList list, Object value,
                                                  int index, boolean isSelected, boolean hasFocus) {
        TextAndIcon tai = (TextAndIcon) value;

        setText(tai.getText());  // HTML text with link
        setIcon(tai.getIcon());
        setIconTextGap(15);
        setHorizontalTextPosition(SwingConstants.RIGHT);
        setVerticalAlignment(SwingConstants.CENTER);

        if (isSelected) {
            setBackground(list.getSelectionBackground());
            setForeground(list.getSelectionForeground());
        } else {
            setBackground(list.getBackground());
            setForeground(list.getForeground());
        }

        Border outsideBorder = hasFocus
                ? UIManager.getBorder("List.focusCellHighlightBorder")
                : NO_FOCUS_BORDER;

        setBorder(BorderFactory.createCompoundBorder(outsideBorder, insideBorder));
        setComponentOrientation(list.getComponentOrientation());
        setEnabled(list.isEnabled());
        setFont(list.getFont());

        return this;
    }

    // Performance overrides (unchanged from original)
    @Override public void validate() {}
    @Override public void invalidate() {}
    @Override public void repaint() {}
    @Override public void revalidate() {}
    @Override public void repaint(long tm, int x, int y, int width, int height) {}
    @Override public void repaint(Rectangle r) {}
}