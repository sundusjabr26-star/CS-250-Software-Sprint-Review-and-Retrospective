import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.FlowLayout;
import java.awt.HeadlessException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import java.awt.Color;

public class SlideShow extends JFrame {

	// Declare Variables
	private JPanel slidePane;
	private JPanel textPane;
	private JPanel buttonPane;
	private CardLayout card;
	private CardLayout cardText;
	private JButton btnPrev;
	private JButton btnNext;
	private JLabel lblSlide;
	private JLabel lblTextArea;

	/**
	 * Create the application.
	 */
	public SlideShow() throws HeadlessException {
		initComponent();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initComponent() {

		// Initialize layout managers
		card = new CardLayout();
		cardText = new CardLayout();

		// Initialize panels
		slidePane = new JPanel();
		textPane = new JPanel();
		buttonPane = new JPanel();

		// Set background for text panel
		textPane.setBackground(Color.BLUE);

		// Initialize buttons and labels
		btnPrev = new JButton();
		btnNext = new JButton();
		lblSlide = new JLabel();
		lblTextArea = new JLabel();

		// Setup frame attributes
		setSize(800, 600);
		setLocationRelativeTo(null);

		// Updated title based on Product Owner requirement
		setTitle("Top 5 Wellness & Detox Travel Destinations");

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(new BorderLayout());

		// Set layouts
		slidePane.setLayout(card);
		textPane.setLayout(cardText);

		// Load slides and descriptions
		// Updated to reflect wellness travel theme
		for (int i = 1; i <= 5; i++) {
			lblSlide = new JLabel();
			lblTextArea = new JLabel();

			// Load images (unchanged)
			lblSlide.setText(getResizeIcon(i));

			// Load updated wellness descriptions
			lblTextArea.setText(getTextDescription(i));

			slidePane.add(lblSlide, "card" + i);
			textPane.add(lblTextArea, "cardText" + i);
		}

		// Add panels to frame
		getContentPane().add(slidePane, BorderLayout.CENTER);
		getContentPane().add(textPane, BorderLayout.SOUTH);

		// Setup button panel
		buttonPane.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

		btnPrev.setText("Previous");
		btnPrev.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goPrevious();
			}
		});
		buttonPane.add(btnPrev);

		btnNext.setText("Next");
		btnNext.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				goNext();
			}
		});
		buttonPane.add(btnNext);

		getContentPane().add(buttonPane, BorderLayout.NORTH);
	}

	/**
	 * Previous Button Functionality
	 */
	private void goPrevious() {
		card.previous(slidePane);
		cardText.previous(textPane);
	}

	/**
	 * Next Button Functionality
	 */
	private void goNext() {
		card.next(slidePane);
		cardText.next(textPane);
	}

	/**
	 * Method to get the images
	 * Updated to reflect detox/wellness travel theme
	 */
	private String getResizeIcon(int i) {
		String image = ""; 

		if (i == 1) {
			// Yoga retreat image
			image = "<html><body><img width='800' height='500' src='" 
					+ getClass().getResource("/resources/yoga.jpg") + "'></body></html>";

		} else if (i == 2) {
			// Spa wellness image
			image = "<html><body><img width='800' height='500' src='" 
					+ getClass().getResource("/resources/spa.jpg") + "'></body></html>";

		} else if (i == 3) {
			// Meditation retreat image
			image = "<html><body><img width='800' height='500' src='" 
					+ getClass().getResource("/resources/meditation.jpg") + "'></body></html>";

		} else if (i == 4) {
			// Nature detox image
			image = "<html><body><img width='800' height='500' src='" 
					+ getClass().getResource("/resources/nature.jpg") + "'></body></html>";

		} else if (i == 5) {
			// Wellness resort image
			image = "<html><body><img width='800' height='500' src='" 
					+ getClass().getResource("/resources/wellness.jpg") + "'></body></html>";
		}

		return image;
	}


	/**
	 * Method to get the text values
	 * Updated to reflect detox/wellness travel requirement
	 */
	private String getTextDescription(int i) {
		String text = "";

		if (i == 1) {
			text = "<html><body><font size='5'>#1 Yoga Retreat.</font><br>Relax and rejuvenate with guided yoga sessions.</body></html>";
		} else if (i == 2) {
			text = "<html><body><font size='5'>#2 Spa Getaway.</font><br>Luxury spa treatments for detox and relaxation.</body></html>";
		} else if (i == 3) {
			text = "<html><body><font size='5'>#3 Meditation Camp.</font><br>Improve mental wellness through meditation.</body></html>";
		} else if (i == 4) {
			text = "<html><body><font size='5'>#4 Nature Detox.</font><br>Reconnect with nature and cleanse your mind.</body></html>";
		} else if (i == 5) {
			text = "<html><body><font size='5'>#5 Wellness Resort.</font><br>All-inclusive health and wellness experience.</body></html>";
		}

		return text;
	}

	/**
	 * Launch the application
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				SlideShow ss = new SlideShow();
				ss.setVisible(true);
			}
		});
	}
}
